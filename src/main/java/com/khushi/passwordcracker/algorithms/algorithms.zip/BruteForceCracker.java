package com.khushi.passwordcracker.algorithms;

import com.khushi.passwordcracker.utils.HashUtil;

public class BruteForceCracker {

    private static final String CHARACTERS = "abcdefghijklmnopqrstuvwxyz";

    public static String crackPassword(String targetHash, int maxLength) {

        for (int length = 1; length <= maxLength; length++) {

            String result = generate("", length, targetHash);

            if (result != null) {
                return result;
            }
        }

        return null;
    }

    private static String generate(String current, int remainingLength, String targetHash) {

        if (remainingLength == 0) {

            String hash = HashUtil.generateSHA256(current);

            if (hash.equals(targetHash)) {
                return current;
            }

            return null;
        }

        for (int i = 0; i < CHARACTERS.length(); i++) {

            String result = generate(
                    current + CHARACTERS.charAt(i),
                    remainingLength - 1,
                    targetHash);

            if (result != null) {
                return result;
            }
        }

        return null;
    }
}