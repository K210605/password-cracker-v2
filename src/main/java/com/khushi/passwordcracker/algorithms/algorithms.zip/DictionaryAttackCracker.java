package com.khushi.passwordcracker.algorithms;

import com.khushi.passwordcracker.dictionary.Wordlist;
import com.khushi.passwordcracker.utils.HashUtil;

public class DictionaryAttackCracker {

    public static String crackPassword(String targetHash) {

        for (String word : Wordlist.PASSWORDS) {

            String hash = HashUtil.generateSHA256(word);

            if (hash.equals(targetHash)) {
                return word;
            }
        }

        return null;
    }
}