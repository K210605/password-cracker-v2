package com.khushi.passwordcracker.algorithms;

import com.khushi.passwordcracker.utils.HashUtil;
import com.khushi.passwordcracker.dictionary.Wordlist;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class HybridAttackCracker {

    private int attemptsCount = 0;

    public String crack(String targetHash){

        attemptsCount = 0;

        for (String word : Wordlist.PASSWORDS) {

            List<String> candidates = generateMutations(word);

            for (String candidate : candidates) {

                attemptsCount++;

                String candidateHash = HashUtil.generateSHA256(candidate);

                if (candidateHash.equals(targetHash)) {
                    return candidate;
                }
            }
        }

        return "Not Found";
    }

    private List<String> generateMutations(String word) {

        List<String> mutations = new ArrayList<>();

        mutations.add(word);
        mutations.add(capitalize(word));
        mutations.add(word + "123");
        mutations.add(word + "1");
        mutations.add(word + "!");
        mutations.add(word + "@");
        mutations.add(word + "2024");
        mutations.add(word + "2025");
        mutations.add(capitalize(word) + "123");
        mutations.add(capitalize(word) + "!");
        mutations.add(leetSpeak(word));
        mutations.add(capitalize(leetSpeak(word)));
        mutations.add(reverse(word));

        return mutations;
    }

    private String capitalize(String word) {

        if (word.isEmpty())
            return word;

        return Character.toUpperCase(word.charAt(0)) + word.substring(1);
    }

    private String leetSpeak(String word) {

        return word.replace('a', '@')
                .replace('A', '@')
                .replace('o', '0')
                .replace('O', '0')
                .replace('e', '3')
                .replace('E', '3')
                .replace('i', '1')
                .replace('I', '1')
                .replace('s', '$')
                .replace('S', '$');
    }

    private String reverse(String word) {

        return new StringBuilder(word).reverse().toString();
    }

    public int getAttemptsCount() {

        return attemptsCount;
    }
}
